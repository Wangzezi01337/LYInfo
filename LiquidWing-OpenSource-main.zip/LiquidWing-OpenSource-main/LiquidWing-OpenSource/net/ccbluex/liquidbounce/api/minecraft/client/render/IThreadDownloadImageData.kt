
package net.ccbluex.liquidbounce.api.minecraft.client.render

import net.ccbluex.liquidbounce.api.minecraft.client.render.texture.IAbstractTexture

interface IThreadDownloadImageData : IAbstractTexture