
package net.ccbluex.liquidbounce.api.minecraft.client.entity.player

interface IEntityOtherPlayerMP : IEntityPlayer