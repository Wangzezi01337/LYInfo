
package net.ccbluex.liquidbounce.api.minecraft.util

interface IFoodStats {
    val foodLevel: Int
}