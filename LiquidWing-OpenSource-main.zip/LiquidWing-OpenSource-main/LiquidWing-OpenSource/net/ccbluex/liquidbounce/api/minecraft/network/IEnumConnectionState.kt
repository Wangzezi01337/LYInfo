
package net.ccbluex.liquidbounce.api.minecraft.network

interface IEnumConnectionState {
    val isHandshake: Boolean
}