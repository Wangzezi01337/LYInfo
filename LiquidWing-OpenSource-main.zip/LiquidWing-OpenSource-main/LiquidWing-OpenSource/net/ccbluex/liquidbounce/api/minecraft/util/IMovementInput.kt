
package net.ccbluex.liquidbounce.api.minecraft.util

interface IMovementInput {
    val moveForward: Float
    val moveStrafe: Float
    val jump: Boolean
}