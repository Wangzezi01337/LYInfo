
package net.ccbluex.liquidbounce.api.util

abstract class WrappedGuiTextField